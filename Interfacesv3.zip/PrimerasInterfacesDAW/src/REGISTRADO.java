import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.TextField;
import java.awt.TextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class REGISTRADO extends JFrame {

	private JPanel contentPane;
	/**
	 * @wbp.nonvisual location=-20,529
	 */
	private final JPanel panel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					REGISTRADO frame = new REGISTRADO();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public REGISTRADO() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 865, 483);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(239, 239, 239));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_4_2_1 = new JLabel("");
		lblNewLabel_4_2_1.setBackground(new Color(255, 255, 255));
		lblNewLabel_4_2_1.setIcon(new ImageIcon("C:\\Users\\fernando\\Downloads\\icons8-usuario-100.png"));
		lblNewLabel_4_2_1.setBounds(115, 186, 100, 95);
		contentPane.add(lblNewLabel_4_2_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		panel_1.setBackground(new Color(0, 64, 128));
		panel_1.setBounds(-33, 0, 884, 127);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_4_2 = new JLabel("");
		lblNewLabel_4_2.setBounds(203, 21, 470, 95);
		lblNewLabel_4_2.setIcon(new ImageIcon("C:\\Users\\fernando\\Desktop\\logo-medac.png"));
		panel_1.add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_4_1 = new JLabel("");
		lblNewLabel_4_1.setBounds(673, 50, 0, 0);
		panel_1.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(678, 50, 0, 0);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel = new JLabel("User resgistered succesfully");
		lblNewLabel.setFont(lblNewLabel.getFont().deriveFont(lblNewLabel.getFont().getStyle() | Font.BOLD));
		lblNewLabel.setBounds(46, 130, 169, 34);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("Copyright © 2021 the trustees of MEDAC center");
		lblNewLabel_3.setBounds(283, 391, 299, 20);
		contentPane.add(lblNewLabel_3);
		
		JButton botonCamara = new JButton("");
		botonCamara.setBackground(new Color(244, 244, 244));
		botonCamara.setSelectedIcon(new ImageIcon("C:\\Users\\fernando\\Downloads\\icons8-añadir-cámara-64.png"));
		botonCamara.setIcon(new ImageIcon("C:\\Users\\fernando\\Downloads\\icons8-añadir-cámara-64.png"));
		botonCamara.setBounds(189, 243, 70, 56);
		contentPane.add(botonCamara);
		
		JLabel lblWriteSomethingAbout = new JLabel("Write something about yourself");
		lblWriteSomethingAbout.setFont(lblWriteSomethingAbout.getFont().deriveFont(lblWriteSomethingAbout.getFont().getStyle() | Font.BOLD));
		lblWriteSomethingAbout.setBounds(367, 130, 351, 34);
		contentPane.add(lblWriteSomethingAbout);
		
		TextField cuentamesobreti = new TextField();
		cuentamesobreti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cuentamesobreti.setSelectionEnd(10);
		cuentamesobreti.setBounds(367, 164, 305, 163);
		contentPane.add(cuentamesobreti);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_2.setBounds(58, 165, 259, 162);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblAddAPicture = new JLabel("Add a picture");
		lblAddAPicture.setBounds(79, 137, 83, 14);
		lblAddAPicture.setFont(lblAddAPicture.getFont().deriveFont(lblAddAPicture.getFont().getStyle() | Font.BOLD));
		panel_2.add(lblAddAPicture);
	}
}

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.TextField;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Button;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextPane;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.ImageIcon;
import javax.swing.border.LineBorder;
import java.awt.FlowLayout;
import javax.swing.JSeparator;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.MatteBorder;
import javax.swing.border.EtchedBorder;
import java.awt.SystemColor;
import javax.swing.border.CompoundBorder;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.border.BevelBorder;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class PrimeraInterfaz extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField txtFirstName;
	private JTextField campomail;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrimeraInterfaz frame = new PrimeraInterfaz();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings("deprecation")
	public PrimeraInterfaz() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 865, 463);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(234, 234, 234));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBackground(new Color(250, 250, 250));
		textField.setBounds(167, 184, 199, 28);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("First Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(77, 148, 79, 40);
		contentPane.add(lblNewLabel);
		
		JLabel lblContrasea = new JLabel("Last name");
		lblContrasea.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblContrasea.setBounds(77, 178, 79, 40);
		contentPane.add(lblContrasea);
		
		txtFirstName = new JTextField();
		txtFirstName.setBackground(new Color(250, 250, 250));
		txtFirstName.setColumns(10);
		txtFirstName.setBounds(167, 154, 132, 28);
		contentPane.add(txtFirstName);
		
		JLabel lblEmail = new JLabel("Password");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEmail.setBounds(76, 261, 66, 40);
		contentPane.add(lblEmail);
		
		JLabel lblEmail_1 = new JLabel("Email");
		lblEmail_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEmail_1.setBounds(77, 226, 66, 28);
		contentPane.add(lblEmail_1);
		
		campomail = new JTextField();
		campomail.setBackground(new Color(250, 250, 250));
		campomail.setColumns(10);
		campomail.setBounds(167, 222, 354, 28);
		contentPane.add(campomail);
		
		final JLabel lblMustContainAt = new JLabel("Must contain at least 15 caracters");
		lblMustContainAt.hide();
		lblMustContainAt.setFont(lblMustContainAt.getFont().deriveFont(lblMustContainAt.getFont().getStyle() | Font.ITALIC, 9f));
		lblMustContainAt.setBounds(413, 269, 154, 28);
		contentPane.add(lblMustContainAt);
		
		JLabel lblNewLabel_3 = new JLabel("Copyright © 2021 the trustees of MEDAC center");
		lblNewLabel_3.setBounds(252, 393, 269, 20);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\fernando\\Desktop\\logo-medac.png"));
		lblNewLabel_4.setBounds(176, 10, 653, 110);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblRepeatPassword = new JLabel("Repeat Password");
		lblRepeatPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblRepeatPassword.setBounds(23, 301, 137, 40);
		contentPane.add(lblRepeatPassword);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 2, true));
		panel.setBackground(new Color(0, 64, 128));
		panel.setBounds(-15, 0, 884, 127);
		contentPane.add(panel);
		
		final JCheckBox checkpolitica = new JCheckBox("I accept the conditions of service and the policy of the MEDAC center");
		checkpolitica.setFont(new Font("Tahoma", Font.BOLD, 10));
		checkpolitica.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				
			}
		});
		checkpolitica.setBackground(new Color(237, 237, 237));
		checkpolitica.setBounds(223, 356, 381, 23);
		contentPane.add(checkpolitica);
		
	
		JButton btnRegistrarse = new JButton("Sign Up");
		
		btnRegistrarse.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				if (checkpolitica.isSelected() && passwordField.getText().equals(passwordField_1.getText())&& !txtFirstName.getText().isEmpty() && !passwordField.getText().isEmpty() && campomail.getText().contains("@") && campomail.getText().contains(".")) {
								REGISTRADO obj= new REGISTRADO();
									obj.setVisible(true);
									dispose();	 
						
				}else if (!passwordField.getText().equals(passwordField_1.getText())) {
					 JOptionPane.showMessageDialog(null, "Una de las contraseñas no es correcta.");
				}
				else if (!checkpolitica.isSelected()) {
					 JOptionPane.showMessageDialog(null, "Es obligatorio seleccionar las condiciones antes de registrarse.");
				}
				else if (!campomail.getText().contains("@") && !campomail.getText().contains(".") ) {
					 JOptionPane.showMessageDialog(null, "Tu correo no es correcto.");
				}
				else if (txtFirstName.getText().isEmpty() && textField.getText().isEmpty() ) {
					 JOptionPane.showMessageDialog(null,  "Rellena los campos de nombre y apellido.");
				}
				else if (passwordField_1.getText().isEmpty() && passwordField.getText().isEmpty() ) {
					 JOptionPane.showMessageDialog(null,  "Rellena el campo de las contraseñas.");
				}
			}
		});
		
		
		
		btnRegistrarse.setBackground(new Color(192, 192, 192));
		btnRegistrarse.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnRegistrarse.setBounds(44, 352, 173, 28);
		contentPane.add(btnRegistrarse);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(234, 234, 234));
		panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_1.setBounds(605, 131, 224, 279);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Log In");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(91, 45, 60, 28);
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBounds(10, 72, 66, 1);
		panel_1.add(panel_1_1);
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel_1_1_1.setBounds(148, 72, 66, 1);
		panel_1.add(panel_1_1_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("with");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(96, 64, 36, 28);
		panel_1.add(lblNewLabel_1_1);
		
		JButton btnNewButton_1_1 = new JButton("");
		btnNewButton_1_1.addMouseListener(new MouseAdapter() {
			@SuppressWarnings("deprecation")
			@Override
			public void mouseClicked(MouseEvent e) {
				new loginGOOGLE().setVisible(true);
				loginGOOGLE obj= new loginGOOGLE();
				obj.show();
			}
		});
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1_1.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
			}
		});
		btnNewButton_1_1.setBackground(new Color(255, 255, 196));
		btnNewButton_1_1.setIcon(new ImageIcon("C:\\Users\\fernando\\Downloads\\Google-G-Logo (1).png"));
		btnNewButton_1_1.setBounds(27, 118, 51, 34);
		panel_1.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("");
		btnNewButton_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				  try {
				         
				        Desktop.getDesktop().browse(new URI("https://www.facebook.com"));
				         
				    } catch (IOException | URISyntaxException e1) {
				        e1.printStackTrace();
				    }
			}
		});
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1_1_1.setBackground(SystemColor.textHighlight);
		btnNewButton_1_1_1.setIcon(new ImageIcon("C:\\Users\\fernando\\Downloads\\fb_icon_325x325 (2).png"));
		btnNewButton_1_1_1.setBounds(87, 118, 51, 34);
		panel_1.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_1_1 = new JButton("");
		btnNewButton_1_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 try {
			         
				        Desktop.getDesktop().browse(new URI("https://www.icloud.com/"));
				         
				    } catch (IOException | URISyntaxException e1) {
				        e1.printStackTrace();
				    }
			}
		});
		btnNewButton_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1_1_1_1.setBackground(new Color(0, 0, 0));
		btnNewButton_1_1_1_1.setIcon(new ImageIcon("C:\\Users\\fernando\\Downloads\\pngegg (4) (1).png"));
		btnNewButton_1_1_1_1.setBounds(148, 118, 51, 34);
		panel_1.add(btnNewButton_1_1_1_1);
		
		passwordField = new JPasswordField();
		passwordField.setBackground(new Color(250, 250, 250));
		passwordField.setBounds(167, 269, 179, 28);
		contentPane.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBackground(new Color(250, 250, 250));
		passwordField_1.setBounds(167, 306, 179, 28);
		contentPane.add(passwordField_1);
		
		final JCheckBox chckbxVerClave = new JCheckBox("Show");
		chckbxVerClave.setFont(new Font("Tahoma", Font.BOLD, 10));
		chckbxVerClave.setBackground(new Color(237, 237, 237));
		chckbxVerClave.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				
				if(chckbxVerClave.isSelected()) {
					System.out.println("Estas viendo la contraseña");
					passwordField.setEchoChar((char)0);
				}else {
					System.out.println("No estas viendo la contraseña");
					passwordField.setEchoChar('•');
				}	
			}
			
		});
		chckbxVerClave.setBounds(350, 272, 60, 23);
		contentPane.add(chckbxVerClave);
		
		
	}
}

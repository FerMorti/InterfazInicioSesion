package Clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class Usuario {

	static void ComprobarDatos(String Nombre, String password) {

		CONEXION conexion = new CONEXION();
		Connection cn = null;
		Statement stm = null;
		ResultSet rs = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/usuarios", "root", "");
			Statement stmt = con.createStatement();
			ResultSet rs1 = stmt.executeQuery("SELECT * FROM usuarios WHERE Nombre = '" + Nombre + "' AND Contraseña = '" + password + "'");
			if (rs1.next()) {
				Registrado obj = new Registrado();
				obj.setVisible(true);
			} else {
				JOptionPane.showMessageDialog(null, "Tanto el usuario como la contraseña son incorrectos.");
			}
			con.close();
		} catch (Exception error) {
			System.out.println(error);
		}
	}

	static void InsertarDatos(String Nombre, String Apellido, String mail, String Contraseña) {

		CONEXION conexion = new CONEXION();
		Connection cn = null;
		PreparedStatement stm = null;
		ResultSet rs = null;

		try {
			cn = conexion.conectar();
			PreparedStatement stm2 = cn
					.prepareStatement("INSERT INTO usuarios(Nombre,Apellidos,Mail,Contraseña) VALUES (?,?,?,?)");
			stm2.setString(1, Nombre);
			stm2.setString(2, Apellido);
			stm2.setString(3, mail);
			stm2.setString(4, Contraseña);

			stm2.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();

		} finally {
			try {
				if (rs != null) {
					rs.close();
				}

				if (stm != null) {
					stm.close();
				}

				if (cn != null) {
					cn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}
}

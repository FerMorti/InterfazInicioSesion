/**
 * 
 */
/**
 * @author fernando
 *
 */
module InterfacesDEFINITIVASDEVERDAD {
	requires java.desktop;
	requires java.sql;
}
package Clases;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField Usuariolog;
	private JPanel panel;
	private JLabel lblNewLabel_2;
	private JPasswordField Contraseñalog;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 865, 483);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(237, 237, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("User/E-Mail");
		lblNewLabel.setFont(new Font("Verdana", Font.PLAIN, 13));
		lblNewLabel.setBounds(286, 238, 123, 24);
		contentPane.add(lblNewLabel);
		
		Usuariolog = new JTextField();
		Usuariolog.setForeground(new Color(0, 0, 255));
		Usuariolog.setBounds(372, 240, 175, 24);
		contentPane.add(Usuariolog);
		Usuariolog.setColumns(10);
		
		JLabel lblContrasea = new JLabel("Password");
		lblContrasea.setFont(new Font("Verdana", Font.PLAIN, 13));
		lblContrasea.setBounds(286, 273, 123, 24);
		contentPane.add(lblContrasea);
		
		panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBounds(392, 159, 123, 42);
		contentPane.add(panel);
		
		JButton btnLogIn = new JButton("Log in");
		panel.add(btnLogIn);
		btnLogIn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
	
		String Nombre = Usuariolog.getText();
		String password = Contraseñalog.getText();
		
				final Usuario comprobarDATOS = new Usuario();
				Usuario.ComprobarDatos(Usuariolog.getText(), Contraseñalog.getText());
			}
				});
		btnLogIn.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnLogIn.setBackground(Color.LIGHT_GRAY);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\fernando\\Desktop\\Nueva carpeta (3)\\INTERFACESV3\\Interfacesv3\\imagenes\\logo.png"));
		lblNewLabel_2.setBounds(284, 0, 329, 155);
		contentPane.add(lblNewLabel_2);
		
		Contraseñalog = new JPasswordField();
		Contraseñalog.setBounds(372, 273, 175, 24);
		contentPane.add(Contraseñalog);
		
		final JCheckBox chckbxVerClave2 = new JCheckBox("Show");
		chckbxVerClave2.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				if(chckbxVerClave2.isSelected()) {
					System.out.println("Estas viendo la contraseña");
					Contraseñalog.setEchoChar((char)0);
				}else {
					System.out.println("No estas viendo la contraseña");
					Contraseñalog.setEchoChar('•');	
			}
			}
		});
		chckbxVerClave2.setBackground(new Color(237, 237, 237));
		chckbxVerClave2.setBounds(553, 275, 60, 23);
		contentPane.add(chckbxVerClave2);
		
		lblNewLabel_3 = new JLabel("Copyright © 2021 the trustees of GOOGLE enterprise");
		lblNewLabel_3.setBounds(317, 390, 298, 20);
		contentPane.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Have you forgotten your password?");
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 try {
			         
				        Desktop.getDesktop().browse(new URI("https://accounts.google.com/v3/signin/identifier?dsh=S839776679%3A1679073876830973&hl=es&ifkv=AWnogHehb-Mhfum93yAIy8SPcrEkYJvlvmoiRBYr74-1AbdcyyZlaPiaFfrlWGFcQwN4mm7zNWCsYA&flowName=GlifWebSignIn&flowEntry=ServiceLogin"));
				         
				    } catch (IOException | URISyntaxException e1) {
				        e1.printStackTrace();
				    }
			}
		});
		lblNewLabel_4.setForeground(new Color(0, 0, 255));
		lblNewLabel_4.setBackground(new Color(0, 0, 255));
		lblNewLabel_4.setFont(lblNewLabel_4.getFont().deriveFont(lblNewLabel_4.getFont().getStyle() | Font.ITALIC));
		lblNewLabel_4.setBounds(364, 308, 208, 20);
		contentPane.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("Create an account");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 try {
			         
				        Desktop.getDesktop().browse(new URI("https://accounts.google.com/signup/v2/webcreateaccount?biz=false&cc=ES&dsh=S554689808%3A1679073987384066&flowEntry=SignUp&flowName=GlifWebSignIn&hl=es&ifkv=AWnogHc1RAZiZu8VLbFKu_CtuCLmvKD7BMUW-DxsOpEwVHFRyyEAmcuc2ZSEo7ug1sGKlMomM_6zlg"));
				         
				    } catch (IOException | URISyntaxException e1) {
				        e1.printStackTrace();
				    }
				
			}
		});
		lblNewLabel_5.setForeground(Color.BLUE);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_5.setBackground(Color.BLUE);
		lblNewLabel_5.setBounds(403, 359, 123, 20);
		contentPane.add(lblNewLabel_5);
	}

}

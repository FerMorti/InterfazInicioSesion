package Clases;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TABLAclase extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;

    public TABLAclase() {
        setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new String[]{"Nombre", "Apellidos", "Mail"}, 0);
        table = new JTable(tableModel);

        JButton actualizarButton = new JButton("Update");
        actualizarButton.setBackground(new Color(204, 204, 204));
        actualizarButton.setIcon(new ImageIcon("C:\\Users\\fernando\\Downloads\\Oxygen-Icons.org-Oxygen-Actions-edit-redo.256 (2).png"));
        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarTabla();
            }
        });

        JButton eliminarButton = new JButton("Delete");
        eliminarButton.setBackground(new Color(204, 204, 204));
        eliminarButton.setIcon(new ImageIcon("C:\\Users\\fernando\\Downloads\\Proyecto nuevo.png"));
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    String nombre = tableModel.getValueAt(row, 0).toString();
                    eliminarUsuario(nombre);
                }
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(actualizarButton);
        buttonPanel.add(eliminarButton);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        JLabel lblNewLabel = new JLabel("Base de Datos MEDAC");
        lblNewLabel.setForeground(SystemColor.activeCaption);
        lblNewLabel.setFont(new Font("Monospaced", Font.BOLD, 12));
        lblNewLabel.setBackground(new Color(0, 0, 160));
        add(lblNewLabel, BorderLayout.NORTH);
    }

    private void actualizarTabla() {
        tableModel.setRowCount(0);

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios", "root", "");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT Nombre, Apellidos, Mail FROM usuarios");

            while (rs.next()) {
                String nombreUsuario = rs.getString("Nombre");
                String apellidosUsuario = rs.getString("Apellidos");
                String correoUsuario = rs.getString("Mail");
                tableModel.addRow(new Object[]{nombreUsuario, apellidosUsuario, correoUsuario});
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void eliminarUsuario(String nombre) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios", "root", "");
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM usuarios WHERE Nombre = ?");
            stmt.setString(1, nombre);
            stmt.executeUpdate();

            stmt.close();
            conn.close();

            actualizarTabla();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Tabla de Usuarios");
        TABLAclase tabla = new TABLAclase();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400); 
        frame.getContentPane().add(tabla);
        frame.setVisible(true);
    }
}
